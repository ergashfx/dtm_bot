variyantuz = {
        'MATEMATIKA': "https://t.me/testiszlar/11",
        'KIMYO': "https://t.me/testiszlar/15",
        'BIOLOGIYA': "https://t.me/testiszlar/12",
        'FIZIKA': "https://t.me/testiszlar/13",
        'TARIX': "https://t.me/testiszlar/16",
        'ONA TILI': "https://t.me/testiszlar/18",
        'GEOGRAFIYA': "https://t.me/testiszlar/14",
        'INGLIZ TILI': "https://t.me/testiszlar/17",
        'NEMIS TILI': "https://t.me/testiszlar/26",
        'FRANSUZ TILI': "https://t.me/testiszlar/25"}

variyantuz2 = {
        'MATEMATIKA': "https://t.me/testiszlar/190",
        'KIMYO': "https://t.me/testiszlar/174",
        'BIOLOGIYA': "https://t.me/testiszlar/189",
        'FIZIKA': "https://t.me/testiszlar/186",
        'TARIX': "https://t.me/testiszlar/191",
        'ONA TILI': "https://t.me/testiszlar/175",
        'GEOGRAFIYA': "https://t.me/testiszlar/187",
        'INGLIZ TILI': "https://t.me/testiszlar/192",
        'NEMIS TILI': "https://t.me/testiszlar/193",
        'FRANSUZ TILI': "https://t.me/testiszlar/188"}

uzbtest = {
        'MATEMATIKA': "1010",
        'KIMYO': "1014",
        'BIOLOGIYA': "1011",
        'FIZIKA': "1012",
        'TARIX': "1015",
        'ONA TILI': "1017",
        'GEOGRAFIYA': "1013",
        'INGLIZ TILI': "1016",
        'NEMIS TILI': "1025",
        'FRANSUZ TILI': "1024"}


rutest = {
        'МАТЕМАТИКА': "https://t.me/testiszlar/20",
        'ХИМИЯ': "https://t.me/testiszlar/23",
        'БИОЛОГИЯ': "https://t.me/testiszlar/19",
        'ФИЗИКА': "https://t.me/testiszlar/21",
        'ИСТОРИЯ': "https://t.me/testiszlar/24",
        'РУССКИЙ ЯЗЫК': "https://t.me/testiszlar/27",
        'ГЕОГРАФИЯ': "https://t.me/testiszlar/22",
        "ФРАНЦУЗСКИЙ ЯЗЫК": "https://t.me/testiszlar/25",
        "АНГЛИЙСКИЙ ЯЗЫК": "https://t.me/testiszlar/17",
        "НЕМЕЦКИЙ ЯЗЫК": "https://t.me/testiszlar/26"}

rutest2 = {
        'МАТЕМАТИКА': "https://t.me/testiszlar/213",
        'ХИМИЯ': "https://t.me/testiszlar/210",
        'БИОЛОГИЯ': "https://t.me/testiszlar/215",
        'ФИЗИКА': "https://t.me/testiszlar/208",
        'ИСТОРИЯ': "https://t.me/testiszlar/214",
        'РУССКИЙ ЯЗЫК': "https://t.me/testiszlar/212",
        'ГЕОГРАФИЯ': "https://t.me/testiszlar/217",
        "ФРАНЦУЗСКИЙ ЯЗЫК": "https://t.me/testiszlar/211",
        "АНГЛИЙСКИЙ ЯЗЫК": "https://t.me/testiszlar/209",
        "НЕМЕЦКИЙ ЯЗЫК": "https://t.me/testiszlar/216"}

rutestnum={
        'МАТЕМАТИКА': "1019",
        'ХИМИЯ': "1022",
        'БИОЛОГИЯ': "1018",
        'ФИЗИКА': "1020",
        'ИСТОРИЯ': "1023",
        'РУССКИЙ ЯЗЫК': "1026",
        'ГЕОГРАФИЯ': "1021",
        "ФРАНЦУЗСКИЙ ЯЗЫК": "1024",
        "АНГЛИЙСКИЙ ЯЗЫК": "1016",
        "НЕМЕЦКИЙ ЯЗЫК": "1025",
    }

blokli1 = [
    {
        "Matematika(2020)":"https://t.me/testiszlar/31?single",
        "Fizika 2019": "https://t.me/testiszlar/35",
        "Fizika 2020": "https://t.me/testiszlar/36?single",
        "Kimyo 2019": "https://t.me/testiszlar/39",
        "Biologiya 2020": "https://t.me/testiszlar/49",
    }
]

blokli2 = [
    {
        "Matematika(2020)":"https://t.me/testiszlar/51",
        "Fizika 2019": "https://t.me/testiszlar/55",
        "Fizika 2020": "https://t.me/testiszlar/38",
        "Kimyo 2019": "https://t.me/testiszlar/44?single",
        "Biologiya 2020": "https://t.me/testiszlar/50",
    }
]

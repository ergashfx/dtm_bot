raqamlar = [
    {
        'Matematika': "1010",
        'Kimyo': "1014",
        'Biologiya': "1011",
        'Ona tili': "1017",
        'Tarix': "1015",
        'Fizika': "1012",
        'Ingliz tili': "1016",
        'Geografiya': "1013"
    }
]
javoblar = [
    {
        '1010': "dbbaccbaadbacaaddabaabcdabaddc",
        '1011': "caaaaadaabaaacabaaabbaaaaabaad",
        '1012': "dcddbcbdaaabcbcabbadcbaccabbba",
        '1013': "ccdacabccabababcdcdadadcbbaccb",
        '1014': "ccbaacbaaddbbcaccabbabadbbdcdc",
        '1015': "abdcdddaaabcaabbccbabbcdcbdcad",
        '1016': "ababbbdbdbcdbabaacbcdcacbbdbaa",
        '1017': "accbcbaddcbbaadadbacbdabaabcaa",
        '1018': "caaaaadaabaaacabaaabbaaaaabaaa",
        '1019': "dbbaccaaddbacaaddabaabcdcbaddc",
        '1020': "abdaccbdcaaacdadbdcacabccabbbb",
        '1021': "ccdabacccabababcdbdadadcbbaccb",
        '1022': "ccbaacbaaddbbcaccabbabadbbdcdc",
        '1023': "bdcddacaacccdacabbaaadadcababa",
        '1024': "ccdbcdccacddcabbdbbadaccdabadd",
        '1025': "abcbcbadacbcbaadcccbdccadaccaa",
        '1026': "aacbabadbdacbacdadababaccbdbac"
    }
]

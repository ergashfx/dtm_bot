from . import variyantlar

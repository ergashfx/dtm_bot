from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from data.config import btns
blok = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(text="Matematika(2020)"),
        KeyboardButton(text="Fizika 2019")
    ],
    [
        KeyboardButton(text="Fizika 2020"),
        KeyboardButton(text="Kimyo 2019")
    ],
    [
        KeyboardButton(text="Biologiya 2020"),
    ],
    [
        KeyboardButton(text=btns["back"])
    ]

],
    resize_keyboard=True,
)
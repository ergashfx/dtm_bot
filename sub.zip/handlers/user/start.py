from aiogram import types
from aiogram.dispatcher import FSMContext

from handlers.user.admin import create_user
from keyboards.default.keyboard import mainM
from loader import dp


@dp.message_handler(text=["/start", "Ortga qaytish"])
async def welcome(msg: types.Message, state: FSMContext):
    name = msg.from_user.full_name
    await msg.answer(f"Salom {name}", reply_markup=mainM)
    await state.finish()
